/* 滚动按钮 - 后台服务：工具栏图标点击改为弹窗菜单（popup.html），此处保留启动时机与兜底通道 */
'use strict';

/* 首次安装：自动打开用法教程页（更新时不打扰） */
chrome.runtime.onInstalled.addListener((details) => {
  if (details && details.reason === 'install') {
    try { chrome.tabs.create({ url: chrome.runtime.getURL('guide.html') }); } catch (err) { /* 忽略 */ }
  }
});

/* 空监听器：为 MV3 service worker 提供启动时机，确保消息监听注册稳定 */
chrome.runtime.onStartup.addListener(() => {});

/* 回退通道：接收页面发来的"打开设置页"请求（仅在使用网络页挡窗口时为兜底） */
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'esb-open-options') {
    chrome.runtime.openOptionsPage();
  }
});
